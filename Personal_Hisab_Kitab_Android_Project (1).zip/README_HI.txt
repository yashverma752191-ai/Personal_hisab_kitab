PERSONAL HISAB-KITAB — Android project

फ़ीचर: आमदनी/खर्च, उधार और भुगतान, कैश/बैंक/UPI खाते, बैलेंस, तारीख/खोज फ़िल्टर, CSV (Excel), प्रिंट से PDF, JSON बैकअप/रीस्टोर। डेटा WebView localStorage में डिवाइस पर रहता है; ऐप ऑफलाइन काम करता है।

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio और Android SDK (API 35) इंस्टॉल करें।
2. Android Studio > Open > इस ZIP को extract करने के बाद PersonalHisabKitab फ़ोल्डर खोलें।
3. Gradle sync पूरा होने दें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK सामान्यतः app/build/outputs/apk/debug/app-debug.apk में बनेगा।
6. APK को अपने Android फोन में भेजें और अनुमति मिलने पर install करें।

महत्वपूर्ण:
- इस वातावरण में Android SDK/Gradle उपलब्ध नहीं था, इसलिए यहाँ compiled APK नहीं बनाया जा सका। यह Android Studio में build करने योग्य source project और standalone HTML app है।
- JSON बैकअप नियमित रूप से डाउनलोड करके सुरक्षित रखें। ऐप का डेटा साफ करने या uninstall करने पर स्थानीय डेटा मिट सकता है।
- PDF विकल्प प्रिंट डायलॉग खोलता है; वहाँ Save as PDF चुनें।
